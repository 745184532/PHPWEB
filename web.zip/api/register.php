<?php

    print_r(json_encode($_POST,JSON_UNESCAPED_UNICODE));
?>