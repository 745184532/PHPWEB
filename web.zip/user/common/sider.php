<div class="sider">
    <ul>
        <li class="menu">
            <a href="./usercenter.php" class="link">用户信息 </a>
        </li>
        <li class="menu">
            <a href="#" class="link">登录记录 </a>
        </li>
        <li class="menu">
            <a href="#" class="link">修改密码 </a>
        </li>
        <li class="menu">
            <a href="#" class="link">退出登录 </a>
        </li>
    </ul>
</div>