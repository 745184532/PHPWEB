<div class="header">
    <div class="container-full">
        <div class="sitename">
            猫叔的网站
        </div>
        <div class="userinfo">
            <span class="username">
                测试用户1
            </span>
            <a href="#">退出</a>
        </div>
    </div>
</div>
